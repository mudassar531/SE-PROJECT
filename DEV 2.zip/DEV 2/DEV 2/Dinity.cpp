#include"Dinity.h"
#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
#include<string.h>
using namespace std;

//Functions For Food Items
food_items::food_items()             //Default Constructor
{
    item_id = 0;
    item_name = " ";
    quantity = 0;
    price = 0;
}
//Getters
int food_items::get_item_id()
{
    return item_id;
}
string food_items::get_item_name()
{
    return item_name;
}
int food_items::get_item_quantity()
{
    return quantity;
}
int food_items::get_item_price()
{
    return price;
}
//Setters
void food_items::set_item_id(int id)
{
    item_id = id;
}
void food_items::set_item_name(string str)
{
    item_name = str;
}
void food_items::set_item_quantity(int q)
{
    quantity = q;
}
void food_items::set_item_price(int p)
{
    price = p;
}

void  food_items::Display_items()
{
    cout << item_id << "\t" << item_name << "( " << quantity << " )" << "_________" << price << " Rs " << endl;
}


//Functions For Customer
Customer::Customer()                              //Default Constructor
{
    string name = " ";
    string email = " ";
    string address = " ";
    string phone = " ";
    food_items* items_selected = NULL;
    int count = 0;
}
//Getters
string Customer::get_name()
{
    return name;
}
string Customer::get_email()
{
    return email;
}
string Customer::get_address()
{
    return address;
}
string Customer::get_phone()
{
    return phone;
}
food_items  Customer::get_items_selected()
{
    return *items_selected;
}
//Setters
void Customer::set_name(std::string C_name)
{
    name = C_name;
}
void Customer::set_email(std::string C_email)
{
    email = C_email;
}
void Customer::set_address(std::string C_address)
{
    address = C_address;
}
void Customer::set_phone(std::string C_phone)
{
    phone = C_phone;
}
void Customer::set_items_selected(food_items* items)
{
    for (int i = 0; i < count; count++)
    {
        items_selected[i] = items[i];
    }
}

//Function for Online Order
void Customer::onlineOrder(food_items Menu[50])
{
    string CustomerName, CustomerAddress, CustomerEmail, CustomerNumber;
    int total = 0, confirm;
    int id[15], quantity[15];
    int i = 0, l = 0;
    int repeat = 1;
    food_items* items_selected = new food_items[10];

    cout << "\n\n\t\t**************CART***************\n\n";
    for (int m = 0; m < count - 1; m++)
    {
        items_selected[m].Display_items();
    }
    cout << "\nTotal______________________________" << total;
    cout << endl << endl;

    cout << "Press '1' to confirm and '0' to cancel your order : ";
    cin >> confirm;

    if (confirm == 1)
    {
        ofstream file1;
        file1.open("Customer_details.txt", ios::app);

        if (file1.is_open())
        {

            file1 << "_____________________________________\n";

            cout << "Enter your Name: ";
            cin.ignore();
            getline(cin, CustomerName);
            set_name(CustomerName);
            file1 << "Customer Name: " << CustomerName << endl;
            cout << "Enter your Address: ";
            cin.ignore();
            getline(cin, CustomerAddress);
            set_address(CustomerAddress);

            file1 << "Customer Address: " << CustomerAddress << endl;
            cout << "Enter your Email: ";
            cin >> CustomerEmail;
            set_email(CustomerEmail);
            file1 << "Customer Email: " << CustomerEmail << endl;
            cout << "Enter your Phone Number: ";
            cin >> CustomerNumber;
            set_phone(CustomerNumber);
            file1 << "Customer Phone Number: " << CustomerNumber << endl;
            file1 << "Total Amount: " << total << endl;
            file1 << "_____________________________________\n";
            file1.close();
        }
        else
        {
            cout << "Unable to open file\n";
        }
    }
    else if (confirm == 0)
    {
        cout << "\nYour Order has been canceled\n";
    }
    else
    {
        cout << "\nInvalid Input\n";
    }


    delete[] items_selected;
}