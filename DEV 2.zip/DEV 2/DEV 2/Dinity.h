#pragma once
#ifndef Dinity_h_
#define Dinity_h_
#include<iostream>
using namespace std;
#include<cstring>
class food_items
{
private:
    int item_id;
    std::string item_name;
    int quantity;
    int price;
public:
    food_items();
    int get_item_id();
    std::string get_item_name();
    int get_item_quantity();
    int get_item_price();

    void set_item_id(int);
    void set_item_name(std::string);
    void set_item_quantity(int);
    void set_item_price(int);

    void Display_items();
};

class Table {
private:
    int no_of_table[10];
    int your_table;
public:
    Table() {
        for (int i = 0; i < 10; i++) {
            no_of_table[i] = 0;
        }
    }
    void reserve_table(int x) {
        no_of_table[x] = 1;
        your_table = 1;
    }
    int see_your_table() {
        cout << "\Your Table Number is:\t\t";
        for (int i = 1; i < 11; i++) {
            if (no_of_table[i] == 1) {
                cout << i << " ";
            }
        }
    }
    void see_empty_table() {
        cout << "\nEmpty Table Numbers:\t\t";
        for (int i = 0; i < 11; i++) {
            if (no_of_table[i] == 0) {
                cout << i << " ";
            }
        }
    }
};


class Customer {
private:
    std::string name;
    std::string email;
    std::string address;
    std::string phone;
    food_items* items_selected;
    int count;
public:
    Customer();
    std::string get_name();
    std::string get_email();
    std::string get_address();
    std::string get_phone();
    food_items get_items_selected();
    void set_name(std::string C_name);
    void set_email(std::string C_email);
    void set_address(std::string C_address);
    void set_phone(std::string C_phone);
    void set_items_selected(food_items* items);
    void onlineOrder(food_items Menu[20]);
};


#endif