#include"Dinity.h"
#include<iostream>
#include<cstring>
#include<string>
#include<fstream>
using namespace std;

void Display_menu(food_items Menu[50]);

int main()
{

    bool repeat = 1;

    food_items Menu[50];

    while (repeat == 1)
    {
        int N = 10;
        Customer C;
        string read_data = " ";

        Menu[0].set_item_id(1);
        Menu[0].set_item_name("Green Salad");
        Menu[0].set_item_quantity(0);
        Menu[0].set_item_price(70);
        Menu[1].set_item_id(2);
        Menu[1].set_item_name("Raita");
        Menu[1].set_item_quantity(0);
        Menu[1].set_item_price(50);
        Menu[2].set_item_id(3);
        Menu[2].set_item_name("French Fries");
        Menu[2].set_item_quantity(0);
        Menu[2].set_item_price(100);
        Menu[3].set_item_id(4);
        Menu[3].set_item_name("Chicken Strips");
        Menu[3].set_item_quantity(0);
        Menu[3].set_item_price(150);
        Menu[4].set_item_id(5);
        Menu[4].set_item_name("Finger Fish");
        Menu[4].set_item_quantity(0);
        Menu[4].set_item_price(200);
        Menu[5].set_item_id(6);
        Menu[5].set_item_name("Chicken Corn Soup");
        Menu[5].set_item_quantity(0);
        Menu[5].set_item_price(150);
        Menu[6].set_item_id(7);
        Menu[6].set_item_name("Fish Crackers");
        Menu[6].set_item_quantity(0);
        Menu[6].set_item_price(160);
        Menu[7].set_item_id(8);
        Menu[7].set_item_name("Halwa Puri");
        Menu[7].set_item_quantity(0);
        Menu[7].set_item_price(160);
        Menu[8].set_item_id(9);
        Menu[8].set_item_name("Omelette");
        Menu[8].set_item_quantity(0);
        Menu[8].set_item_price(70);
        Menu[9].set_item_id(10);
        Menu[9].set_item_name("Cheese Omelette");
        Menu[9].set_item_quantity(0);
        Menu[9].set_item_price(150);
        Menu[10].set_item_id(11);
        Menu[10].set_item_name("Naan Chanay");
        Menu[10].set_item_quantity(0);
        Menu[10].set_item_price(100);
        Menu[11].set_item_id(12);
        Menu[11].set_item_name("Club Sandwich");
        Menu[11].set_item_quantity(0);
        Menu[11].set_item_price(140);
        Menu[12].set_item_id(13);
        Menu[12].set_item_name("French Toast");
        Menu[12].set_item_quantity(0);
        Menu[12].set_item_price(80);
        Menu[13].set_item_id(14);
        Menu[13].set_item_name("Chicken Cheese Paratha");
        Menu[13].set_item_quantity(0);
        Menu[13].set_item_price(250);
        Menu[14].set_item_id(15);
        Menu[14].set_item_name("Chicken Grilled Sandwich");
        Menu[14].set_item_quantity(0);
        Menu[14].set_item_price(200);

        Menu[15].set_item_id(16);
        Menu[15].set_item_name("Chicken Paratha");
        Menu[15].set_item_quantity(0);
        Menu[15].set_item_price(150);
        Menu[16].set_item_id(17);
        Menu[16].set_item_name("Paya");
        Menu[16].set_item_quantity(0);
        Menu[16].set_item_price(300);
        Menu[17].set_item_id(18);
        Menu[17].set_item_name("Nehari");
        Menu[17].set_item_quantity(0);
        Menu[17].set_item_price(300);
        Menu[18].set_item_id(19);
        Menu[18].set_item_name("Chicken Karahi");
        Menu[18].set_item_quantity(0);
        Menu[18].set_item_price(800);
        Menu[19].set_item_id(20);
        Menu[19].set_item_name("Mutton Karahi");
        Menu[19].set_item_quantity(0);
        Menu[19].set_item_price(1000);
        Menu[20].set_item_id(21);
        Menu[20].set_item_name("Chicken Jalfrezi");
        Menu[20].set_item_quantity(0);
        Menu[20].set_item_price(700);
        Menu[21].set_item_id(22);
        Menu[21].set_item_name("Chicken Ginger");
        Menu[21].set_item_quantity(0);
        Menu[21].set_item_price(700);
        Menu[22].set_item_id(23);
        Menu[22].set_item_name("Chicken White Karahi");
        Menu[22].set_item_quantity(0);
        Menu[22].set_item_price(900);
        Menu[23].set_item_id(24);
        Menu[23].set_item_name("Mutton Spinach");
        Menu[23].set_item_quantity(0);
        Menu[23].set_item_price(450);
        Menu[24].set_item_id(25);
        Menu[24].set_item_name("Chicken Biryani");
        Menu[24].set_item_quantity(0);
        Menu[24].set_item_price(400);
        Menu[25].set_item_id(26);
        Menu[25].set_item_name("Sindhi Chicken Biryani");
        Menu[25].set_item_quantity(0);
        Menu[25].set_item_price(500);
        Menu[26].set_item_id(27);
        Menu[26].set_item_name("Fried Rice");
        Menu[26].set_item_quantity(0);
        Menu[26].set_item_price(300);
        Menu[27].set_item_id(28);
        Menu[27].set_item_name("Mutton Pulao");
        Menu[27].set_item_quantity(0);
        Menu[27].set_item_price(500);
        Menu[28].set_item_id(29);
        Menu[28].set_item_name("Beef Pulao");
        Menu[28].set_item_quantity(0);
        Menu[28].set_item_price(400);
        Menu[29].set_item_id(30);
        Menu[29].set_item_name("Cheese Nan");
        Menu[29].set_item_quantity(0);
        Menu[29].set_item_price(150);
        Menu[30].set_item_id(31);
        Menu[30].set_item_name("Garlic Nan");
        Menu[30].set_item_quantity(0);
        Menu[30].set_item_price(40);
        Menu[31].set_item_id(32);
        Menu[31].set_item_name("Kalonji Nan");
        Menu[31].set_item_quantity(0);
        Menu[31].set_item_price(35);
        Menu[32].set_item_id(33);
        Menu[32].set_item_name("Plain Nan");
        Menu[32].set_item_quantity(0);
        Menu[32].set_item_price(20);
        Menu[33].set_item_id(34);
        Menu[33].set_item_name("Roti");
        Menu[33].set_item_quantity(0);
        Menu[33].set_item_price(20);
        Menu[34].set_item_id(35);
        Menu[34].set_item_name("Kheer");
        Menu[34].set_item_quantity(0);
        Menu[34].set_item_price(150);
        Menu[35].set_item_id(36);
        Menu[35].set_item_name("Fruit Triffle");
        Menu[35].set_item_quantity(0);
        Menu[35].set_item_price(150);
        Menu[36].set_item_id(37);
        Menu[36].set_item_name("Rus malai");
        Menu[36].set_item_quantity(0);
        Menu[36].set_item_price(100);
        Menu[37].set_item_id(38);
        Menu[37].set_item_name("Jalaybee");
        Menu[37].set_item_quantity(0);
        Menu[37].set_item_price(100);
        Menu[38].set_item_id(39);
        Menu[38].set_item_name("Rus Gullay");
        Menu[38].set_item_quantity(0);
        Menu[38].set_item_price(60);
        Menu[39].set_item_id(40);
        Menu[39].set_item_name("Gulab Jaman");
        Menu[39].set_item_quantity(0);
        Menu[39].set_item_price(60);
        Menu[40].set_item_id(41);
        Menu[40].set_item_name("Cappuccino");
        Menu[40].set_item_quantity(0);
        Menu[40].set_item_price(110);
        Menu[41].set_item_id(42);
        Menu[41].set_item_name("Black Coffee");
        Menu[41].set_item_quantity(0);
        Menu[41].set_item_price(90);
        Menu[42].set_item_id(43);
        Menu[42].set_item_name("Mix Tea");
        Menu[42].set_item_quantity(0);
        Menu[42].set_item_price(50);
        Menu[43].set_item_id(44);
        Menu[43].set_item_name("Green Tea");
        Menu[43].set_item_quantity(0);
        Menu[43].set_item_price(45);
        Menu[44].set_item_id(45);
        Menu[44].set_item_name("Soft Drinks Cans");
        Menu[44].set_item_quantity(0);
        Menu[44].set_item_price(70);
        Menu[45].set_item_id(46);
        Menu[45].set_item_name("Cold Coffee");
        Menu[45].set_item_quantity(0);
        Menu[45].set_item_price(100);
        Menu[46].set_item_id(47);
        Menu[46].set_item_name("Fresh Juice");
        Menu[46].set_item_quantity(0);
        Menu[46].set_item_price(120);
        Menu[47].set_item_id(48);
        Menu[47].set_item_name("Mint Margarita");
        Menu[47].set_item_quantity(0);
        Menu[47].set_item_price(120);
        Menu[48].set_item_id(49);
        Menu[48].set_item_name("Oreo Shake");
        Menu[48].set_item_quantity(0);
        Menu[48].set_item_price(120);
        Menu[49].set_item_id(50);
        Menu[49].set_item_name("Lemon Soda");
        Menu[49].set_item_quantity(0);
        Menu[49].set_item_price(100);

        int option;

        cout << "\nChoose the Option: \n";
        cout << "1. Online Order\n";
        cout << "2. Give Feedback\n";
        cout << "3. View Feedback\n";
        cout << "4. Reserve Table\n";

        cin >> option;
        switch (option)
        {
        case 1: {
            Display_menu(Menu);
            C.onlineOrder(Menu);
        }
              break;
        case 4: {
            Table t;
            int op;
        beep:
            cout << "1. See Available Tables:\n";
            cout << "2. Reserve Available Tables:\n";
            cin >> op;
            if (op == 1) {
                t.see_empty_table();
            }
            goto beep;
            if (op == 2) {
                int x;
                cout << "Enter table number to reserve:\t"; cin >> x;
                t.reserve_table(x);
                cout << "\nDone";
            }
            break;
        }
        default: cout << "Invalid Input\n";
        }


        cout << "\nPress '1' to continue and '0' to stop: ";
        cin >> repeat;                                                                        //Error handeling needed here

    }


    return 0;
}


void Display_menu(food_items Menu[])
{

    cout << "\n\n\t_______________________MENU ______________________\n";
    cout << "\t___________________________________________________\n\n\n";

    cout << "\t\t__...***...STARTERS...***...__\n\n";
    cout << "\t" << Menu[0].get_item_id() << ".  " << Menu[0].get_item_name() << "_______________________" << Menu[0].get_item_price() << " Rs\n";
    cout << "\t" << Menu[1].get_item_id() << ".  " << Menu[1].get_item_name() << "_____________________________" << Menu[1].get_item_price() << " Rs\n";
    cout << "\t" << Menu[2].get_item_id() << ".  " << Menu[2].get_item_name() << "_____________________" << Menu[2].get_item_price() << " Rs\n";
    cout << "\t" << Menu[3].get_item_id() << ".  " << Menu[3].get_item_name() << "___________________" << Menu[3].get_item_price() << " Rs\n";
    cout << "\t" << Menu[4].get_item_id() << ".  " << Menu[4].get_item_name() << "______________________" << Menu[4].get_item_price() << " Rs\n";
    cout << "\t" << Menu[5].get_item_id() << ".  " << Menu[5].get_item_name() << "________________" << Menu[5].get_item_price() << " Rs\n";
    cout << "\t" << Menu[6].get_item_id() << ".  " << Menu[6].get_item_name() << "____________________" << Menu[6].get_item_price() << " Rs\n";
    cout << "\n\t\t__...***...BREAKFAST...***...__\n\n";
    cout << "\t" << Menu[7].get_item_id() << ".  " << Menu[7].get_item_name() << "_______________________" << Menu[7].get_item_price() << " Rs\n";
    cout << "\t" << Menu[8].get_item_id() << ".  " << Menu[8].get_item_name() << "__________________________" << Menu[8].get_item_price() << " Rs\n";
    cout << "\t" << Menu[9].get_item_id() << ". " << Menu[9].get_item_name() << "__________________" << Menu[9].get_item_price() << " Rs\n";
    cout << "\t" << Menu[10].get_item_id() << ". " << Menu[10].get_item_name() << "______________________" << Menu[10].get_item_price() << " Rs\n";
    cout << "\t" << Menu[11].get_item_id() << ". " << Menu[11].get_item_name() << "____________________" << Menu[11].get_item_price() << " Rs\n";
    cout << "\t" << Menu[12].get_item_id() << ". " << Menu[12].get_item_name() << "______________________" << Menu[12].get_item_price() << " Rs\n";
    cout << "\t" << Menu[13].get_item_id() << ". " << Menu[13].get_item_name() << "___________" << Menu[13].get_item_price() << " Rs\n";
    cout << "\t" << Menu[14].get_item_id() << ". " << Menu[14].get_item_name() << "_________" << Menu[14].get_item_price() << " Rs\n";
    cout << "\t" << Menu[15].get_item_id() << ".  " << Menu[15].get_item_name() << "_________________" << Menu[15].get_item_price() << " Rs\n";
    cout << "\t" << Menu[16].get_item_id() << ".  " << Menu[16].get_item_name() << "____________________________" << Menu[16].get_item_price() << " Rs\n";
    cout << "\t" << Menu[17].get_item_id() << ". " << Menu[17].get_item_name() << "___________________________" << Menu[17].get_item_price() << " Rs\n";
    cout << "\n\t\t__...***...CURRIES...***...__\n\n";
    cout << "\t" << Menu[18].get_item_id() << ". " << Menu[18].get_item_name() << "___________________" << Menu[18].get_item_price() << " Rs\n";
    cout << "\t" << Menu[19].get_item_id() << ". " << Menu[19].get_item_name() << "___________________" << Menu[19].get_item_price() << " Rs\n";
    cout << "\t" << Menu[20].get_item_id() << ". " << Menu[20].get_item_name() << "_________________" << Menu[20].get_item_price() << " Rs\n";
    cout << "\t" << Menu[21].get_item_id() << ". " << Menu[21].get_item_name() << "___________________" << Menu[21].get_item_price() << " Rs\n";
    cout << "\t" << Menu[22].get_item_id() << ". " << Menu[22].get_item_name() << "_____________" << Menu[22].get_item_price() << " Rs\n";
    cout << "\t" << Menu[23].get_item_id() << ". " << Menu[23].get_item_name() << "___________________" << Menu[23].get_item_price() << " Rs\n";
    cout << "\n\t\t__...***...RICE...***...__\n\n";
    cout << "\t" << Menu[24].get_item_id() << ". " << Menu[24].get_item_name() << "__________________" << Menu[24].get_item_price() << " Rs\n";
    cout << "\t" << Menu[25].get_item_id() << ". " << Menu[25].get_item_name() << "___________" << Menu[25].get_item_price() << " Rs\n";
    cout << "\t" << Menu[26].get_item_id() << ". " << Menu[26].get_item_name() << "_______________________" << Menu[26].get_item_price() << " Rs\n";
    cout << "\t" << Menu[27].get_item_id() << ". " << Menu[27].get_item_name() << "_____________________" << Menu[27].get_item_price() << " Rs\n";
    cout << "\t" << Menu[28].get_item_id() << ". " << Menu[28].get_item_name() << "_______________________" << Menu[28].get_item_price() << " Rs\n";
    cout << "\n\t\t__...***...BREAD...***...__\n\n";
    cout << "\t" << Menu[29].get_item_id() << ". " << Menu[29].get_item_name() << "_______________________" << Menu[29].get_item_price() << " Rs\n";
    cout << "\t" << Menu[30].get_item_id() << ". " << Menu[30].get_item_name() << "________________________" << Menu[30].get_item_price() << " Rs\n";
    cout << "\t" << Menu[31].get_item_id() << ". " << Menu[31].get_item_name() << "_______________________" << Menu[31].get_item_price() << " Rs\n";
    cout << "\t" << Menu[32].get_item_id() << ". " << Menu[32].get_item_name() << "_________________________" << Menu[32].get_item_price() << " Rs\n";
    cout << "\t" << Menu[33].get_item_id() << ". " << Menu[33].get_item_name() << "______________________________" << Menu[33].get_item_price() << " Rs\n";
    cout << "\n\t\t__...***...SWEET...***...__\n\n";
    cout << "\t" << Menu[34].get_item_id() << ". " << Menu[34].get_item_name() << "____________________________" << Menu[34].get_item_price() << " Rs\n";
    cout << "\t" << Menu[35].get_item_id() << ". " << Menu[35].get_item_name() << "____________________" << Menu[35].get_item_price() << " Rs\n";
    cout << "\t" << Menu[36].get_item_id() << ". " << Menu[36].get_item_name() << "________________________" << Menu[36].get_item_price() << " Rs\n";
    cout << "\t" << Menu[37].get_item_id() << ". " << Menu[37].get_item_name() << "_________________________" << Menu[37].get_item_price() << " Rs\n";
    cout << "\t" << Menu[38].get_item_id() << ". " << Menu[38].get_item_name() << "________________________" << Menu[38].get_item_price() << " Rs\n";
    cout << "\t" << Menu[39].get_item_id() << ". " << Menu[39].get_item_name() << "_______________________" << Menu[39].get_item_price() << " Rs\n";
    cout << "\n\t\t__...***...BEVERAGES...***...__\n\n";
    cout << "\t" << Menu[40].get_item_id() << ". " << Menu[40].get_item_name() << "_______________________" << Menu[40].get_item_price() << " Rs\n";
    cout << "\t" << Menu[41].get_item_id() << ". " << Menu[41].get_item_name() << "______________________" << Menu[41].get_item_price() << " Rs\n";
    cout << "\t" << Menu[42].get_item_id() << ". " << Menu[42].get_item_name() << "___________________________" << Menu[42].get_item_price() << " Rs\n";
    cout << "\t" << Menu[43].get_item_id() << ". " << Menu[43].get_item_name() << "_________________________" << Menu[43].get_item_price() << " Rs\n";
    cout << "\t" << Menu[44].get_item_id() << ". " << Menu[44].get_item_name() << "__________________" << Menu[44].get_item_price() << " Rs\n";
    cout << "\t" << Menu[45].get_item_id() << ". " << Menu[45].get_item_name() << "______________________" << Menu[45].get_item_price() << " Rs\n";
    cout << "\t" << Menu[46].get_item_id() << ". " << Menu[46].get_item_name() << "______________________" << Menu[46].get_item_price() << " Rs\n";
    cout << "\t" << Menu[47].get_item_id() << ". " << Menu[47].get_item_name() << "___________________" << Menu[47].get_item_price() << " Rs\n";
    cout << "\t" << Menu[48].get_item_id() << ". " << Menu[48].get_item_name() << "_______________________" << Menu[48].get_item_price() << " Rs\n";
    cout << "\t" << Menu[49].get_item_id() << ". " << Menu[49].get_item_name() << "_______________________" << Menu[49].get_item_price() << " Rs\n";

}




